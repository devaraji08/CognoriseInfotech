import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Business_card2(props) {
  return (
    <div className={cn(styles.root, props.className, 'business-card2')}>
      <img className={styles.decorator1} src={'/assets/orange_gradient_triangle.png'} alt="alt text" />
      <img className={styles.decorator} src={'/assets/red_gradient_triangle.png'} alt="alt text" />

      <div className={styles.flex_col}>
        <img className={styles.image} src={'/assets/abstract_orange_logo.png'} alt="alt text" />
        <h1 className={styles.hero_title}>Your tag line here</h1>
      </div>
    </div>
  );
}

Business_card2.propTypes = {
  className: PropTypes.string
};

export default Business_card2;
