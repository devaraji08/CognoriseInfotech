import Business_card2 from './Business_card2';

export default { Business_card2 };
