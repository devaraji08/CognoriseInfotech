import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Ecom(props) {
  return (
    <div className={cn(styles.root, props.className, 'ecom')}>
      <div className={styles.content_box}>
        <img className={styles.image} src={'/assets/gradient_black_gray.png'} alt="alt text" />
        <img className={styles.image1} src={'/assets/solid_black_background.png'} alt="alt text" />
        <h1 className={styles.title_box}>
          <span className={styles.title}>
            <span className={styles.title_span0}>
              Apple iPhone 13(128 GB) - Blue
              <br />
            </span>
            <span className={styles.title_span1}>Visit Apple store</span>
          </span>
        </h1>
        <h2 className={styles.medium_title1}>4.5 </h2>
        <img className={styles.image8} src={'/assets/four_and_half_star_rating.png'} alt="alt text" />
        <div className={styles.rect} />
        <div className={styles.rect1} />
        <h1 className={styles.hero_title1}>Limited time deal</h1>
        <h1 className={styles.hero_title2}>-18%</h1>
        <h1 className={styles.hero_title3}>M.R.P.: ₹59,900</h1>
        <h1 className={styles.hero_title31_box}>
          <span className={styles.hero_title31}>
            <span className={styles.hero_title31_span0}>₹ </span>
            <span className={styles.hero_title31_span1}>49,200</span>
          </span>
        </h1>
        <h1 className={styles.title1_box}>
          <span className={styles.title1}>
            <span className={styles.title1_span0}>
              Inclusive of all taxes
              <br />
            </span>
            <span className={styles.title1_span1}>EMI</span>
            <span className={styles.title1_span2}> starts at ₹2,385</span>
          </span>
        </h1>

        <div className={styles.group}>
          <img className={styles.image9} src={'/assets/smartphone_specification_options.png'} alt="alt text" />
          <img className={styles.decorator1} src={'/assets/smartphone_features_description.png'} alt="alt text" />
        </div>
      </div>

      <div className={styles.group1}>
        <div className={styles.group2}>
          <img className={styles.decorator} src={'/assets/gradient_purple_pink.png'} alt="alt text" />

          <div className={styles.flex_row}>
            <img className={styles.image5} src={'/assets/online_shop_logo.png'} alt="alt text" />
            <h1 className={styles.hero_title}>MEN</h1>
            <h1 className={styles.hero_title}>WOMEN</h1>
            <h1 className={styles.hero_title4}>KIDS</h1>
            <h1 className={styles.hero_title5}>SALE</h1>
          </div>
        </div>

        <div className={styles.content_box1}>
          <img className={styles.image2} src={'/assets/outline_heart_icon.png'} alt="alt text" />
          <img className={styles.image3} src={'/assets/shopping_basket_icon.png'} alt="alt text" />
          <img className={styles.cover} src={'/assets/gradient_white_gray.png'} alt="alt text" />
          <img className={styles.image4} src={'/assets/solid_black_square.png'} alt="alt text" />
          <h5 className={styles.highlight}>Search for products</h5>
          <h2 className={styles.medium_title}>login/sign up</h2>
        </div>

        <div className={styles.content_box2}>
          <img className={styles.image6} src={'/assets/smartphone_front_view.png'} alt="alt text" />
          <img className={styles.image7} src={'/assets/smartphone_advertisement_sequence.png'} alt="alt text" />
          <img className={styles.image14} src={'/assets/qr_code_black_and_white.png'} alt="alt text" />
          <h1 className={styles.hero_title11}>For more details</h1>
        </div>
      </div>

      <div className={styles.content_box3}>
        <img className={styles.cover1} src={'/assets/gradient_magenta_fuchsia.png'} alt="alt text" />
        <img className={styles.image10} src={'/assets/solid_black_rectangle.png'} alt="alt text" />
        <img className={styles.image11} src={'/assets/solid_black_square_2.png'} alt="alt text" />
        <h1 className={styles.hero_title12_box}>
          <span className={styles.hero_title12}>
            <span className={styles.hero_title12_span0}>FREE delivery</span>
            <span className={styles.hero_title12_span1}> </span>
            <span className={styles.hero_title12_span2}>Friday,1 March</span>
            <span className={styles.hero_title12_span3}>
              .<br />
            </span>
            <span className={styles.hero_title12_span4}>
              Details
              <br />
            </span>
            <span className={styles.hero_title12_span5}>Or fastest delivery </span>
            <span className={styles.hero_title12_span6}>Tomorrow, 29 February</span>
            <span className={styles.hero_title12_span7}>
              .Order within <br />
            </span>
            <span className={styles.hero_title12_span8}>
              5 hrs 7 mins
              <br />
              Details
              <br />
              <br />       Delivering to Chennai 60013 -Update location
              <br />
              <br />
            </span>
            <span className={styles.hero_title12_span9}>
              In stock
              <br />
            </span>
            <span className={styles.hero_title12_span10}>
              Ships from      Online shop
              <br />
              Sold by            
            </span>
            <span className={styles.hero_title12_span11}>
              Appario Retail Private Ltd
              <br />
            </span>
            <span className={styles.hero_title12_span12}>
              <br />
              Add a Protection Plan      
              <br />
            </span>
            <span className={styles.hero_title12_span13}>       </span>
            <span className={styles.hero_title12_span14}> Protect + with AppleCare Services -1 Year </span>
            <span className={styles.hero_title12_span15}>for</span>
            <span className={styles.hero_title12_span16}> </span>
            <span className={styles.hero_title12_span17}>
              ₹8,499.00
              <br />
            </span>
            <span className={styles.hero_title12_span18}>
              <br />
            </span>
            <span className={styles.hero_title12_span19}>      </span>
          </span>
        </h1>
        <img className={styles.image12} src={'/assets/solid_black_rectangle_2.png'} alt="alt text" />
        <img className={styles.image13} src={'/assets/solid_black_square_3.png'} alt="alt text" />
        <img className={styles.cover2} src={'/assets/gradient_yellow_orange.png'} alt="alt text" />
        <img className={styles.cover21} src={'/assets/solid_yellow_background.png'} alt="alt text" />
        <h1 className={styles.hero_title41}>             Add to cart</h1>
        <h1 className={styles.hero_title42}>           Buy Now</h1>
        <h1 className={styles.hero_title51_box}>
          <span className={styles.hero_title51}>
            <span className={styles.hero_title51_span0}>
              With Exchange
              <br />
            </span>
            <span className={styles.hero_title51_span1}>Up to ₹ 36,300.00 off</span>
          </span>
        </h1>
        <h1 className={styles.hero_title51_box1}>
          <span className={styles.hero_title51}>
            <span className={styles.hero_title51_span0}>
              Without Exchange
              <br />
            </span>
            <span className={styles.hero_title51_span1}>₹ 36,300.00  </span>
            <span className={styles.hero_title51_span2}>₹59,900.00</span>
          </span>
        </h1>
      </div>
    </div>
  );
}

Ecom.propTypes = {
  className: PropTypes.string
};

export default Ecom;
