import Ecom from './Ecom';

export default { Ecom };
