import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Dashboard(props) {
  return (
    <div className={cn(styles.root, props.className, 'dashboard')}>
      <div className={styles.flex_col}>
        <h1 className={styles.big_title}>Statistics</h1>
        <img className={styles.image3} src={'/assets/fitness_activity_steps_graph.png'} alt="alt text" />
      </div>

      <div className={styles.flex_col1}>
        <div className={styles.flex_row}>
          <h1 className={styles.big_title1}>Sleep</h1>
          <img className={styles.image7} src={'/assets/confirmation_tick_button.png'} alt="alt text" />
        </div>

        <div className={styles.content_box} style={{ '--src': `url(${'/assets/progress_dashboard_modal.png'})` }}>
          <div className={styles.flex_col2}>
            <h2 className={styles.medium_title4}>Today</h2>
            <h2 className={styles.medium_title5}>7.3 hr last night</h2>
          </div>
        </div>
      </div>

      <div className={styles.flex_row1}>
        <img className={styles.image6} src={'/assets/profile_icon_badge.png'} alt="alt text" />
        <h5 className={styles.highlight1}>Alex Jonathan</h5>
      </div>

      <div className={styles.content_box1} style={{ '--src': `url(${'/assets/minimalist_search_bar.png'})` }}>
        <h2 className={styles.medium_title3}>Search Fitness</h2>
      </div>

      <div className={styles.content_box2}>
        <h5 className={styles.highlight_box}>
          <span className={styles.highlight}>
            <span className={styles.highlight_span0}>
              Daily Fitness Dashboard
              <br />
            </span>
            <span className={styles.highlight_span1}>Day 25</span>
          </span>
        </h5>
      </div>

      <img className={styles.image5} src={'/assets/626689c4b343fb6e267721d24a55544b.png'} alt="alt text" />

      <div className={styles.content_box3}>
        <h2 className={styles.medium_title2}>Exercise</h2>
      </div>

      <h2 className={styles.medium_title21}>Foodplan</h2>
      <h2 className={styles.medium_title22}>Dailyhabit</h2>
      <h2 className={styles.medium_title23}>Calories</h2>

      <div className={styles.content_box21} style={{ '--src': `url(${'/assets/media_player_skin.png'})` }}>
        <div className={styles.flex_col3}>
          <h2 className={styles.medium_title1}>Earned Points</h2>
          <h1 className={styles.big_title2}>8.871.99</h1>

          <div className={styles.content_box11}>
            <h5 className={styles.highlight2}>      Height   160 cm</h5>
            <h5 className={styles.highlight3}>Weight     80 kg</h5>

            <div
              className={styles.content_box4}
              style={{ '--src': `url(${'/assets/993a6be6bc1c11634c67ca9dae8d695a.png'})` }}>
              <h1 className={styles.big_title3}>JANUARY</h1>
            </div>
          </div>
        </div>
      </div>

      <div
        className={styles.content_box22}
        style={{ '--src': `url(${'/assets/14eb0133bb3675f707440bfed9c7c7f2.png'})` }}>
        <div className={styles.flex_col4}>
          <h5 className={styles.highlight4}>     Calories</h5>
          <h2 className={styles.medium_title_box}>
            <span className={styles.medium_title}>
              <span className={styles.medium_title_span0}>
                {' '}
                467 Kcal <br />
              </span>
              <span className={styles.medium_title_span1}>      Burned</span>
            </span>
          </h2>
        </div>
      </div>

      <div className={styles.content_box12}>
        <div className={styles.flex_col5}>
          <img className={styles.image2} src={'/assets/16e167770210570ba87a206092378472.png'} alt="alt text" />
          <h5 className={styles.highlight5}>      Running</h5>
          <h2 className={styles.medium_title_box}>
            <span className={styles.medium_title}>
              <span className={styles.medium_title_span0}>
                {' '}
                   816 m<br />
              </span>
              <span className={styles.medium_title_span1}>     Goal Rate</span>
            </span>
          </h2>
        </div>

        <img className={styles.cover} src={'/assets/fc4443614aa85b7821065e125bdcf6ee.png'} alt="alt text" />
      </div>

      <div className={styles.content_box5}>
        <div className={styles.flex_col6}>
          <img className={styles.image} src={'/assets/1dc5ba534d2d16b2b7fd8008ddaf8358.png'} alt="alt text" />
          <h5 className={styles.highlight6}>      Heart rate</h5>
          <h2 className={styles.medium_title_box1}>
            <span className={styles.medium_title}>
              <span className={styles.medium_title_span0}>
                {' '}
                 105 bmp
                <br />
              </span>
              <span className={styles.medium_title_span1}>
                {' '}
                <br />    Heart ratio
              </span>
            </span>
          </h2>
        </div>

        <img className={styles.cover} src={'/assets/547e104943ae40ab9667b38e103663e3.png'} alt="alt text" />
      </div>

      <img className={styles.image1} src={'/assets/ui_navigation_sidebar.png'} alt="alt text" />
      <img className={styles.image8} src={'/assets/fitness_goals_summary_card.png'} alt="alt text" />
    </div>
  );
}

Dashboard.propTypes = {
  className: PropTypes.string
};

export default Dashboard;
