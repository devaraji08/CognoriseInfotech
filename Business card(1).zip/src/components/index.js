import Business_card from './Business_card';

export default { Business_card };
