import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Business_card(props) {
  return (
    <div className={cn(styles.root, props.className, 'business-card')}>
      <div className={styles.content_box}>
        <img className={styles.image1} src={'/assets/ee444fb250cb1231d349fb916e126335.png'} alt="alt text" />
        <img className={styles.image4} src={'/assets/red_gradient_background.png'} alt="alt text" />
        <h3 className={styles.subtitle}>
          your@gmail.com
          <br />
          www.yourwebsitename.com
        </h3>
      </div>

      <div className={styles.flex_row}>
        <img className={styles.image3} src={'/assets/red_phone_icon.png'} alt="alt text" />
        <h5 className={styles.highlight}>
          +000 123 456 7896
          <br />
          +000 123 456 7893
        </h5>
      </div>

      <div className={styles.flex_row1}>
        <img className={styles.image2} src={'/assets/red_pokeball_icon.png'} alt="alt text" />
        <h2 className={styles.medium_title_box}>
          <span className={styles.medium_title}>
            <span className={styles.medium_title_span0}>
              Thomas Smith
              <br />
            </span>
            <span className={styles.medium_title_span1}>Graphic Designer</span>
          </span>
        </h2>
      </div>

      <img className={styles.image5} src={'/assets/sample_qr_code.png'} alt="alt text" />
      <img className={styles.decorator} src={'/assets/red_inverted_triangle.png'} alt="alt text" />

      <div className={styles.content_box1}>
        <img className={styles.image} src={'/assets/78849032f3e226728ffd9640105cbe94.png'} alt="alt text" />
        <img className={styles.image41} src={'/assets/red_gradient_background.png'} alt="alt text" />
        <h3 className={styles.subtitle1}>
          Your street name here
          <br />
          New York City, Zip-000
        </h3>
      </div>

      <img className={styles.decorator1} src={'/assets/orange_triangle.png'} alt="alt text" />
    </div>
  );
}

Business_card.propTypes = {
  className: PropTypes.string
};

export default Business_card;
